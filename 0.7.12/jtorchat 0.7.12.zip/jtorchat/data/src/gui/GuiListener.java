package gui;

import core.Buddy;

public interface GuiListener {
	public String onCommand(Buddy buddy, String s);
}
